/*
 * ContactServiceTest.java
 * Author: Anthony
 * Purpose: Unit tests for the ContactService class to verify functionality of adding, deleting, and updating contacts.
 */

 package contact;

 import static org.junit.Assert.assertEquals;
 import org.junit.Test;
 
 public class ContactServiceTest {
 
     @Test
     public void testAdd() {
         ContactService cs = new ContactService();
         Contact test1 = new Contact("1413252", "John", "Doe", "5555555555", "Sample 24 Drive");
         assertEquals(true, cs.addContact(test1));  // Test successful addition
         assertEquals(false, cs.addContact(test1)); // Test adding a duplicate contact
     }
 
     @Test
     public void testDelete() {
         ContactService cs = new ContactService();
         Contact test1 = new Contact("1413252", "John", "Doe", "5555555555", "Sample 24 Drive");
 
         cs.addContact(test1);
         assertEquals(true, cs.deleteContact("1413252"));  // Test successful deletion
         assertEquals(false, cs.deleteContact("1413253")); // Test deleting non-existent contact
     }
 
     @Test
     public void testUpdate() {
         ContactService cs = new ContactService();
         Contact test1 = new Contact("1413252", "John", "Doe", "5555555555", "Sample 24 Drive");
 
         cs.addContact(test1);
         assertEquals(true, cs.updateContact("1413252", "Jane", "", "1234567890", ""));  // Test successful update
         assertEquals(false, cs.updateContact("1413253", "Jane", "", "1234567890", "")); // Test update on non-existent contact
     }
 
     @Test
     public void testInvalidContact() {
         // Test for invalid Contact creation
         try {
             new Contact("14132529999", "John", "Doe", "555", "Sample 24 Drive Too Long for Address");
         } catch (IllegalArgumentException e) {
             assertEquals("Contact ID must be non-null and 10 characters or fewer.", e.getMessage());
         }
     }
 }
 