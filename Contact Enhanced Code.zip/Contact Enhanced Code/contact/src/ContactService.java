/*
 * ContactService.java
 * Author: Anthony
 * Purpose: Manages a list of contacts with the ability to add, remove, and update contacts.
 */

 package contact;

 import java.util.ArrayList;
 
 public class ContactService {
     // List to store contacts, private for encapsulation
     private ArrayList<Contact> contacts;
 
     // Constructor initializing the ArrayList
     public ContactService() {
         contacts = new ArrayList<>();
     }
 
     // Method to add a contact, checking for duplicates
     public boolean addContact(Contact contact) {
         // Ensure contactID is unique
         for (Contact existingContact : contacts) {
             if (existingContact.getContactID().equals(contact.getContactID())) {
                 return false; // Contact with the same ID already exists
             }
         }
         contacts.add(contact); // Add the contact if no duplicates found
         return true;
     }
 
     // Method to delete a contact by ID
     public boolean deleteContact(String contactID) {
         for (Contact contact : contacts) {
             if (contact.getContactID().equals(contactID)) {
                 contacts.remove(contact);
                 return true;  // Successfully deleted
             }
         }
         return false; // Contact not found
     }
 
     // Method to update contact details, with validation to ensure parameters meet the criteria
     public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
         for (Contact contact : contacts) {
             if (contact.getContactID().equals(contactID)) {
                 // Perform updates only if the values are valid and non-null
                 if (firstName != null && !firstName.isEmpty() && firstName.length() <= 10) {
                     contact.setFirstName(firstName);
                 }
                 if (lastName != null && !lastName.isEmpty() && lastName.length() <= 10) {
                     contact.setLastName(lastName);
                 }
                 if (phoneNumber != null && phoneNumber.matches("\\d{10}")) {
                     contact.setPhoneNumber(phoneNumber);
                 }
                 if (address != null && address.length() <= 30) {
                     contact.setAddress(address);
                 }
                 return true; // Contact successfully updated
             }
         }
         return false;  // Contact not found
     }
 
     // Utility method to retrieve all contacts (optional for UI or API calls)
     public ArrayList<Contact> getAllContacts() {
         return contacts;
     }
 }
 