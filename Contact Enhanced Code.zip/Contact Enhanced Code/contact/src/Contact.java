/*
 * Contact.java
 * Author: Anthony
 * Purpose: Defines a Contact object with appropriate encapsulation, validation, and method implementations.
 */

 package contact;

 public class Contact {
     // Defining fields as private to ensure encapsulation
     private String contactID;
     private String firstName;
     private String lastName;
     private String phoneNumber;
     private String address;
 
     // Constructor with validation for each parameter
     public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
         // Calling setters ensures validation during object creation
         setContactID(contactID);
         setFirstName(firstName);
         setLastName(lastName);
         setPhoneNumber(phoneNumber);
         setAddress(address);
     }
 
     // Getter for contactID
     public String getContactID() {
         return contactID;
     }
 
     // Setter for contactID, ensuring non-null and length <= 10
     public void setContactID(String contactID) {
         if (contactID == null || contactID.length() > 10) {
             throw new IllegalArgumentException("Contact ID must be non-null and 10 characters or fewer.");
         }
         this.contactID = contactID;
     }
 
     // Getter for firstName
     public String getFirstName() {
         return firstName;
     }
 
     // Setter for firstName with validation
     public void setFirstName(String firstName) {
         if (firstName == null || firstName.length() > 10) {
             throw new IllegalArgumentException("First Name must be non-null and 10 characters or fewer.");
         }
         this.firstName = firstName;
     }
 
     // Getter for lastName
     public String getLastName() {
         return lastName;
     }
 
     // Setter for lastName with validation
     public void setLastName(String lastName) {
         if (lastName == null || lastName.length() > 10) {
             throw new IllegalArgumentException("Last Name must be non-null and 10 characters or fewer.");
         }
         this.lastName = lastName;
     }
 
     // Getter for phoneNumber
     public String getPhoneNumber() {
         return phoneNumber;
     }
 
     // Setter for phoneNumber with validation (ensure exactly 10 digits)
     public void setPhoneNumber(String phoneNumber) {
         if (phoneNumber == null || !phoneNumber.matches("\\d{10}")) {
             throw new IllegalArgumentException("Phone Number must be exactly 10 digits.");
         }
         this.phoneNumber = phoneNumber;
     }
 
     // Getter for address
     public String getAddress() {
         return address;
     }
 
     // Setter for address with validation (max 30 characters)
     public void setAddress(String address) {
         if (address == null || address.length() > 30) {
             throw new IllegalArgumentException("Address must be non-null and 30 characters or fewer.");
         }
         this.address = address;
     }
 
     // Overriding toString for better string representation
     @Override
     public String toString() {
         return "Contact [contactID=" + contactID + ", firstName=" + firstName + ", lastName=" + lastName
                 + ", phoneNumber=" + phoneNumber + ", address=" + address + "]";
     }
 }
 